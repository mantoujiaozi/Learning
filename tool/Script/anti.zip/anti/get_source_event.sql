insert overwrite table anti_cheat.sqoop_newsearn_task_ma_master 
select 
id, master_id, apprentice_id, apprentice_remark, apprentice_devote_amount, apprentice_devote_gold_amount, 
valid_days, create_time,0 , mannaul_grey_flag
from newsearn_dp_view.parquet_newsearn_task_ma_master_view
union
select  1,a2.invite_user,a2.userid,'0',0,0,0,full_time,0,true from 
(select * from newsearn_dp_view.parquet_newsearn_task_ma_master_view)a1
right join
(select cast(invite_user as int) as invite_user,cast(userid as int) as userid ,full_time from 
(select invite_user,userid,full_time from   newsearn_dp.parquet_newsearn_events_v2_view where event='InviteReg' and logday='__log_day'
union 
select invite_user,userid,full_time from   newsearn_dp.parquet_newsearn_events_v2_view where event='SignUp' and logday='__log_day' and 
invite_user is not null and invite_user<>'0')g
)a2
on a1.apprentice_id=a2.userid
where a1.apprentice_id is null
;


insert overwrite table anti_cheat.json_newsearn_sales_order_total 
select 
id, code, user_id, product_id, product_type, product_name, credit, cost, status, product_info, 
result_info, remark, create_time, update_time, import_time, audit_time, audit_opinion, auditor, 
evaluate_status, json_openid, rechargeaccount 
from anti_cheat.json_newsearn_sales_order_total where replace(substr(create_time,1,10),'-','')>='__log_day_bf1'
union
select 1,a2.code,a2.userid,a2.product_id,a2.product_type,'商品',trade_amount,100,2,null,null,null,a2.create_time,null,null,null,null,null,1,a2.json_openid,a2.json_openid
from
(select * from anti_cheat.json_newsearn_sales_order_total)a1
right join
(select cast(userid as int) as userid, full_time  as create_time,cast(product_id as int) as product_id,trade_id as code,trade_amount,amount_type as product_type,trade_account as json_openid ,logday 
from   newsearn_dp.parquet_newsearn_events_v2_view  where event='TradeInfo' and logday>='__log_day' 
)a2
on a1.code=a2.code
where a1.code is null
;
