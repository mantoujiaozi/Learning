#!/bin/sh
#auther :yangchao
# Date          :2017/09/01
# Describe      :
##################################################
# 新闻根据商城未审核订单数据，活跃ip数据，app安装列表数据 生成的策略。策略为1. 2. 6. 

cd `dirname $0`


if [ $# -lt 1 ]
then
   log_day=`date -d "-0 day" +%Y%m%d`
   log_day_bf1=`date -d "-1 day" +%Y%m%d`
   log_day_bf2=`date -d "-2 day" +%Y%m%d`
   log_day_bf3=`date -d "-3 day" +%Y%m%d`
   log_day_bf7=`date -d "-7 day" +%Y%m%d`
else
   log_day=`date -d "+1 day $1" +%Y%m%d`
   log_day_bf1=`date -d "-0 day $1" +%Y%m%d`
   log_day_bf2=`date -d "-1 day $1" +%Y%m%d`
   log_day_bf3=`date -d "-2 day $1" +%Y%m%d`
   log_day_bf7=`date -d "-6 day $1" +%Y%m%d`
fi

echo $log_day
echo $log_day_bf1

sql_str=`cat newsearn_unaudited_strategy.sql`

sql_str=${sql_str//__log_day_bf7/$log_day_bf7}
sql_str=${sql_str//__log_day_bf2/$log_day_bf2}
sql_str=${sql_str//__log_day_bf3/$log_day_bf3}

sql_str=${sql_str//__log_day_bf1/$log_day_bf1}
sql_str=${sql_str//__log_day/$log_day}

echo $sql_str
impala-shell -q "$sql_str"

