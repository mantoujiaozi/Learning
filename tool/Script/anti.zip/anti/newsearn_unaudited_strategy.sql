insert overwrite table anti_cheat.newsearn_sales_order_user
SELECT distinct user_id  from  anti_cheat.json_newsearn_sales_order_total  where (replace(substr(create_time,1,10),'-','')>='__log_day'
 or (replace(substr(create_time,1,10),'-','')='__log_day_bf1' and substr(create_time,12,2)='23')
) and product_type in(7,10,20)
; 

insert into table anti_cheat.newsearn_sales_order_user
SELECT distinct cast(b.apprentice_id as int) from 
(SELECT distinct user_id  from  anti_cheat.json_newsearn_sales_order_total  where
(replace(substr(create_time,1,10),'-','')>='__log_day'  or (replace(substr(create_time,1,10),'-','')='__log_day_bf1' and substr(create_time,12,2)='23'))
and product_type in(7,10,20)
)a 
left join
anti_cheat.sqoop_newsearn_task_ma_master b 
on a.user_id=b.master_id;

insert overwrite table  anti_cheat.newsearn_unaudited_strategy_result 
select * from anti_cheat.newsearn_unaudited_strategy_result
union all
select distinct a.code,'不通过',2 from
(select  code
from  anti_cheat.json_newsearn_sales_order_total  where
substr(rechargeAccount,-9) in 
('g1530.com','a7996.com','11163.com','@3202.com','@4057.com','@4059.com','cj1530.cn','@11163.co','@3202.com','@819110.com') and product_type in(7,10,20) and
(replace(substr(create_time,1,10),'-','')>='__log_day'  or (replace(substr(create_time,1,10),'-','')='__log_day_bf1' and substr(create_time,12,2)='23'))
)a;


insert overwrite table  anti_cheat.newsearn_unaudited_strategy_result
select * from anti_cheat.newsearn_unaudited_strategy_result
union all
select b.code,'不通过',7  from 
(select master_id,case when count(cnt)>=10 and sum(cnt)>=4 then 1 when count(cnt)<10 and sum(cnt)>=3 then 1 else 0 end as is_true
from
(
    select master_id
    ,if(unix_timestamp(lead(cast(create_time as string)) over(partition by master_id order by create_time)) - unix_timestamp(cast(create_time as string))<=30,1,0) as cnt
    from anti_cheat.sqoop_newsearn_task_ma_master 
    where replace(substr(cast(create_time as string),1,10),'-','')>='__log_day_bf7'
) a1 group by master_id )a
join
(select * from anti_cheat.json_newsearn_sales_order_total where  product_type in(7,10,20) and (replace(substr(create_time,1,10),'-','')>='__log_day'  or (replace(substr(create_time,1,10),'-','')='__log_day_bf1' and substr(create_time,12,2)='23'))
) b 
on a.master_id=b.user_id
having is_true=1
;

--insert overwrite table  anti_cheat.newsearn_unaudited_strategy_result
--select * from anti_cheat.newsearn_unaudited_strategy_result
--union all
--select distinct code, '不通过',8
--from
--(select distinct  code,'不通过'  ,8 from 
--(SELECT a.user_id,count(DISTINCT a.id) num 
--from 
--(SELECT  id,user_id  from anti_cheat.newsearn_tongdun where logday>='__log_day_bf7' and  id in 
--('9430223','9431643','9430163','9431583','9430133','9431553','9430243','9431663')  GROUP  by user_id ,id) a group by a.user_id having num>=2)b
--join
--(SELECT  user_id, code   from  anti_cheat.json_newsearn_sales_order_total  where   (replace(substr(create_time,1,10),'-','')>='__log_day'  or (replace(substr(create_time,1,10),'-','')='__log_day_bf1' and substr(create_time,12,2)='23'))
--GROUP BY  user_id, code)c
--on b.user_id=cast (c.user_id as string) )g
--
--union all 
--
--(
--	select  distinct code,'不通过',8 from 
--	(
--	    select user_id,code ,count(case when cnt>=2 then apprentice_id else null end) /count(apprentice_id) as r_appretuce 
--            ,count(case when cnt>=2 then apprentice_id else null end) as appretuce_1
--           ,count(apprentice_id) as appretuce_2
--            from 
--            (
--                select c1.*,nvl(c2.dis_cnt_sum,0) as cnt from
--                (
--                    select b1.user_id,b1.code,b2.apprentice_id from
--                    (
--                        SELECT user_id,code   
--                        from anti_cheat.json_newsearn_sales_order_total
--                        where 
--                        (replace(substr(create_time,1,10),'-','') >='__log_day'or (replace(substr(create_time,1,10),'-','')='__log_day_bf1' and substr(create_time,12,2)='23'))
--                        GROUP BY  user_id, code
--                    ) b1
--                    left join
--                    (
--                        select master_id,cast(apprentice_id as string) as apprentice_id from anti_cheat.sqoop_newsearn_task_ma_master
--                    ) b2 on b1.user_id=b2.master_id where b2.apprentice_id is not null
--                ) c1
--                left join
--                (
--                    select a1.user_id,max(a1.dis_cnt) as dis_cnt_sum,max(a1.cnt) as cnt_max from
--                    (
--                        SELECT  user_id,row_number() over(partition by user_id order by id desc) as cnt
--                        ,dense_rank() over(partition by user_id order by id desc) as dis_cnt   
--                        from anti_cheat.newsearn_tongdun where logday>='__log_day_bf7' 
--                       and  id in ('9430223','9431643','9430163','9431583','9430133','9431553','9430243','9431663') 
--                    ) a1 group by a1.user_id 
--                ) c2
--                on c1.apprentice_id = c2.user_id
--            ) d1
--            group by user_id,code  having r_appretuce>=0.2
--	) a2
--);
