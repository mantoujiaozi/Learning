#!/bin/sh
#发送作弊用户的id到redis。只需要传入impala 中的表名（包括库名）和标识作弊用户的id字段，命中规则字段。 
#

cd `dirname $0`

#select  invite_user from tmp.tmp limit 1 "

rm -rf user_reuslt.txt
rm -rf user_expire.txt
#redis-cli -n 0 -h 172.16.11.171 -a coohua flushdb
sleep 3
# 如果规则列没有传入，默认写入的redis key的值为字符串null
reason_column_name="select res from anti_cheat.newsearn_gray_user"
if [ -z $reason_column_name ];then
   impala-shell -B -q "select ' set',userid ,'null'  from anti_cheat.newsearn_gray_user" -o user_result.txt
else
   impala-shell -B -q "select ' set',userid , res  from anti_cheat.newsearn_gray_user" -o user_result.txt
fi
cat user_result.txt |gawk '{print "expire " $2 " 86400"}' > user_expire.txt
unix2dos user_result.txt 
unix2dos user_expire.txt
cat user_result.txt|redis-cli -n 0 -h 172.16.11.171 -a coohua --pipe
cat user_expire.txt|redis-cli -n 0 -h 172.16.11.171 -a coohua --pipe
