#!/bin/sh
# 根据商城订单今日的全量累计数据，生成的策略 3,4,5
cd `dirname $0`

if [ $# -lt 1 ]
then
   log_day=`date -d "-0 day" +%Y%m%d`
else
   log_day=`date -d "+1 day $1" +%Y%m%d`
fi

log_day_bf7=`date -d "-7 day $log_day" +%Y%m%d`

echo $log_day_bf7
echo $log_day



sql_str=`cat newsearn_order_strategy.sql`


sql_str=${sql_str//__log_day_bf7/$log_day_bf7}
sql_str=${sql_str//__log_day/$log_day}

echo $sql_str

impala-shell -q "$sql_str"