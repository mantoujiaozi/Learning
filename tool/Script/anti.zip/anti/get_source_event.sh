#!/bin/sh


if [ $# -lt 1 ]
then
   log_day=`date -d "-0 day" +%Y%m%d`
   log_day_bf1=`date -d "-1 day" +%Y%m%d`
   log_day_bf2=`date -d "-2 day" +%Y%m%d`
else
   log_day=`date -d "+1 day $1" +%Y%m%d`
   log_day_bf1=`date -d "-0 day $1" +%Y%m%d`
   log_day_bf2=`date -d "-1 day $1" +%Y%m%d`
fi

echo $log_day

sql_str=`cat get_source_event.sql`
#sql_str=`cat ./sql/get_source_event.sql`

sql_str=${sql_str//__log_day_bf2/$log_day_bf2}
sql_str=${sql_str//__log_day_bf1/$log_day_bf1}
sql_str=${sql_str//__log_day/$log_day}

echo $sql_str
impala-shell -q "$sql_str"