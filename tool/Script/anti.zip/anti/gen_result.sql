
insert into table  anti_cheat.newsearn_strategy_user_result partition (logday,time)
select userid,type,'today' as logday,'hour' as time  from
(select b.user_id as userid,a.type from
(select * from  anti_cheat.newsearn_unaudited_strategy_result  where res in('不通过'))a
join
(SELECT  code,user_id from  anti_cheat.json_newsearn_sales_order_total)b
on a.code=b.code
group by b.user_id,a.type)g
;

insert into table  anti_cheat.newsearn_strategy_user_result  partition (logday,time)
select userid,type,'today' as logday,'hour' as time from
(select  b.user_id as userid,a.type from 
(select * from  anti_cheat.newsearn_order_strategy_result where res in('不通过'))a
join
(SELECT  code,user_id from  anti_cheat.json_newsearn_sales_order_total)b
on a.code=b.code
group by b.user_id,a.type)g
;

insert overwrite table  anti_cheat.newsearn_gray_user
select userid,group_concat(res,",")as res from 
(
select userid,(case when type=1 then 'ip超过150' when type=2 then '支付宝邮箱不合格' when type=3 then '提现openid大于20' when type=4 then '大额订单超过2笔' when type=5 then '一元活动提现openid超过3' when type=6 then 'app安装列表小于10' when type=7 then '徒弟邀请间隔小于30秒'  when type=8 then '同盾近七天指定规则命中任意两个' when type=9 then '170171' when type=10 then 'ios徒弟超70%'  end) as res from anti_cheat.newsearn_strategy_user_result  where logday='today' and time='hour' group by userid,res
)a group by a.userid;

refresh anti_cheat.newsearn_gray_user;
