insert overwrite  table anti_cheat.newsearn_order_strategy_result
select code,'不通过',3 from
(select code,json_openId,count(1) over(partition by json_openId ) rn
from  anti_cheat.json_newsearn_sales_order_total  where  product_id in (1270,1269,1266,1265,1268,1267,1251) 
and  json_openId <> '' and length(json_openId)>5 and replace(substr(create_time,1,10),'-','')='__log_day'
)g where rn>20 
;

insert overwrite  table anti_cheat.newsearn_order_strategy_result
select * from anti_cheat.newsearn_order_strategy_result
union all
select g.code,'不通过',5 from
(select code,json_openId,count(1) over(partition by json_openId ) rn
from  anti_cheat.json_newsearn_sales_order_total  where  product_id in (1271,940) and  
json_openId <> '' and length(json_openId)>5 and replace(substr(create_time,1,10),'-','')='__log_day'
)g where rn>4
;


insert overwrite  table  anti_cheat.newsearn_order_strategy_result  
--select * from anti_cheat.newsearn_order_strategy_result
--union all
--select code,'不通过',4 from 
--(select user_id,code, count(1) over(partition by user_id) rn from anti_cheat.json_newsearn_sales_order_total 
--where product_type in (2,6,9)  and replace(substr(create_time,1,10),'-','')='__log_day'
--)g where rn>3
--;
select * from anti_cheat.newsearn_order_strategy_result
union all
select code,'不通过',4 from 
(select user_id,code from
  (select  user_id,code, count(1) over(partition by user_id) rn from anti_cheat.json_newsearn_sales_order_total 
where replace(substr(create_time,1,10),'-','')='__log_day'
)g where rn>4)m
join(select user_id,sum(credit) as credit  from anti_cheat.json_newsearn_sales_order_total 
where replace(substr(create_time,1,10),'-','')='__log_day' group by user_id having sum(credit)>40)n
on m.user_id=n.user_id
;

--insert overwrite  table  anti_cheat.newsearn_order_strategy_result
--select * from anti_cheat.newsearn_order_strategy_result
--union all
--select code,'不通过',9 from
--(select user_id,code from anti_cheat.json_newsearn_sales_order_total where replace(substr(create_time,1,10),'-','')='__log_day')a1
--join 
--(select userid,phone_number from newsearn_dp_view.newsearn_user_view 
--where substr(phone_number,1,3) in('170','171'))a2
--on cast (a1.user_id as string)=a2.userid
--;


--insert overwrite  table  anti_cheat.newsearn_order_strategy_result
--select * from anti_cheat.newsearn_order_strategy_result
--union all
--select code,'不通过',9  from 
--(select code,count( a2.userid)/count(a3.apprentice_id) as num from
--	(select user_id,code from anti_cheat.json_newsearn_sales_order_total where replace(substr(create_time,1,10),'-','')='__log_day')a1
--	join 
--	(select master_id,apprentice_id from anti_cheat.sqoop_newsearn_task_ma_master group by master_id,apprentice_id)a3
--	on 
--	a1.user_id=master_id
--	left join
--	(select userid,phone_number from newsearn_dp_view.newsearn_user_view where substr(phone_number,1,3) in('170','171'))a2
--	on cast(a3.apprentice_id as string)=a2.userid
--	group by code
--having num>=0.2)h
--;

--insert overwrite  table  anti_cheat.newsearn_order_strategy_result
--select * from anti_cheat.newsearn_order_strategy_result
--union all
--select  code,'不通过',10  from
--(SELECT * FROM anti_cheat.json_newsearn_sales_order_total where replace(substr(create_time,1,10),'-','')='__log_day')a
--join
--(select b.master_id,count(d.userid)/count(c.apprentice_id) as rate from
--    (select master_id,count(distinct apprentice_id) as cnt  from anti_cheat.sqoop_newsearn_task_ma_master
--    where replace(substr(create_time,1,10),'-','')>='__log_day_bf7'  and replace(substr(create_time,1,10),'-','')<='__log_day'
--    group by master_id having cnt>=10)b
--    join
--    (select master_id,apprentice_id from anti_cheat.sqoop_newsearn_task_ma_master
--    where replace(substr(create_time,1,10),'-','')>='__log_day_bf7' and replace(substr(create_time,1,10),'-','')<='__log_day'
--    group by master_id,apprentice_id)c
--    on b.master_id=c.master_id
--    left join
--    (select * from  newsearn_dp_view.newsearn_user_view where os='ios'
--    )d 
--    on cast(c.apprentice_id as string)=d.userid
--    group by b.master_id
--    having rate>=0.7
--)g
--on a.user_id=master_id
--;
