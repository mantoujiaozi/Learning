#!/bin/sh
#  整合新闻的策略，生成最终需要的结果表
cd `dirname $0`

today=`date +%Y%m%d`
echo $today

if [ $# -lt 1 ]
then
   hour=`date -d '-1 hours' +%H`
else
   hour=$1
fi

echo $hour

sql_str=`cat gen_result.sql`

sql_str=${sql_str//hour/$hour}
sql_str=${sql_str//today/$today}


echo $sql_str

impala-shell -q "$sql_str"

